import discord
from discord.ext import commands
from require.Check import *
def setup(client):
    client.add_cog(invite(client))



class invite(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def invite(self,ctx):
        if check.owner( id = ctx.author.id) == True :
            await ctx.send(f"**Here is the link to invite me**\n> <:linkupdate:1076833857459982406> : https://discord.com/api/oauth2/authorize?client_id={self.client.user.id}&permissions=8&scope=bot")
        else :
            await ctx.send("you haven't authorized to use this command")