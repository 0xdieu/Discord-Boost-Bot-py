import discord
from discord.ext import commands
from require.Check import *
from require.BoostRequire import *
def setup(client):
    client.add_cog(boost(client))



class boost(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def boost(self,ctx, guild_id = None, inv = None,type = None, nb_boost : int = None):
        if check.owner( id = ctx.author.id) == True :
            if guild_id is not None and type is not None or type == "1m" or "3m" and nb_boost is not None or nb_boost is int and inv is not None :
                    boostst = await ctx.send("I boost server  **Status :** <a:On:1076830518924030055> ")               
                    with open(f'db/type/type.json', 'r') as f:
                            typejson =json.load(f)
                    typejson["type"] = type 
                    with open('db/type/type.json', 'w') as f: 
                            json.dump(typejson, f, indent=4)         
                    boost_nb = await main(__guild_id__= guild_id, type=type, nb_boost=nb_boost, INV= inv)
                    await boostst.edit(content =f"**i boost server Status : ** <a:check:1076831002837647370> {boost_nb}/{nb_boost}")
                    return
            else :
                if guild_id is None:
                    await ctx.send("Please specify guild id **like : 10208923489**")
                elif type is None or type != "1m" or "3m":
                    await ctx.send("Please specify an correcte type or boost **like : 1m or 3m**")
                elif nb_boost is not int :
                    await ctx.send("Please specify an correct number of boost **like : 8**")
        else :
            await ctx.send("tu n'es pas autorisé a utilisé cette commande")
        