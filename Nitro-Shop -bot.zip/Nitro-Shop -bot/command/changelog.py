import discord
from discord.ext import commands
import os
from require.Check import *
def setup(client):
    client.add_cog(changelogs(client))


class changelogs(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def changelogs(self,ctx,version):
        if check.owner(id = ctx.author.id) == True:         
            await ctx.message.delete()
            with open(f'command/featurs.json', 'r') as f:
                featurs =json.load(f)
            featurs = featurs["features"]
            embed = discord.Embed(
                title = f"Version : v{version}",
                description= f"{featurs}"
            )
            await ctx.send(embed =embed)
        else :
            await ctx.send("you haven't authorized to use this command")
        