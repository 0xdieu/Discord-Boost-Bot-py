import discord
from discord.ext import commands
import aiohttp
import os
import tasksio
import asyncio
from require.Check import *
def setup(client):
    client.add_cog(setpayment(client))

class setpayment(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def setpayment(self,ctx, type = None, value = None):
        if check.owner( id  = ctx.author.id)
