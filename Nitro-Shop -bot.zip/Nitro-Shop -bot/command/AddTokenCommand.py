import discord
from discord.ext import commands
from require.Check import *
def setup(client):
    client.add_cog(addtoken(client))



class addtoken(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def addtoken(self,ctx, type = None, token = None):
        if check.owner(id = ctx.author.id)== True :
            if type == "1m" or "3m" and token is not None:
                    with open(f"./db/{type}/tokens.txt", "a") as f:
                            f.writelines(f"{token}\r")
                    with open(f'./db/{type}/tokens.json', 'r') as f:
                        prefixes = json.load(f)
                
                    prefixes['tokens'].append(f"{token}")

                    with open(f'./db/{type}/tokens.json', 'w') as f:
                        json.dump(prefixes, f, indent=4) 
                    await ctx.message.delete()

                    await ctx.send("**the token wass added to  your file** <:vyee_icons_boost:1076436511806996531> ")        
                        
            if type == None :
                await ctx.message.delete()
                await ctx.send("**you don't specify a type of token**\n> please respecify the type\n> **Example** ``+addtoken <type = 1m/3m> <token = token>``")
        else :
            await ctx.send("you haven't authorized to use this command")