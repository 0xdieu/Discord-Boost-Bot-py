import discord
from discord.ext import commands

def setup(client):
    client.add_cog(help(client))



class help(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def help(self,ctx):
        embed= discord.Embed(
            title = "<:PC_DiscordModerator:1076815581891797052>・Boost Bot",
            description ="""
**Boost bot command**

**``+addtoken``**
> *This command adds tokens to your database*

> ``+addtoken type : <1m/3m> token : <token>``
            
**``+boost``**
> *Cette command permet de boost des server a partir des tokens*  

> ``+boost guild id : <ID> invite : <code ex : dieu/CuvwqnRv> type : <1m/3m> number boost : <1,2,..>``

**``+invite``**
> *This command allows you to boost servers from tokens*

``+invite``

**``+sendtoken``**
> *This command allows you to send tokens to a user*

> ``+sendtoken <type = 1m/3m> <nombre de token = 1,2,3,..> <User>``
            """,
        color = 0xFD7DCD
        )

        embed.set_author( icon_url= self.client.user.avatar_url , name = self.client.user.name)
        embed.set_thumbnail(url="https://media.discordapp.net/attachments/1076818363080245321/1076818508471615558/pp.gif")
        await ctx.send(embed = embed)