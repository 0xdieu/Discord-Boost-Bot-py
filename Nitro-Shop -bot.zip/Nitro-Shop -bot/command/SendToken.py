import discord
from discord.ext import commands
from require.Check import *
def setup(client):
    client.add_cog(sendtoken(client))



class sendtoken(commands.Cog):
    def __init__(self, client):
        self.client = client

    @commands.command()
    async def sendtoken(self,ctx,type = None , nb_token = None , USER : discord.User = None):
        if check.owner( id = ctx.author.id) == True :
            if type is not None and type == "1m" or "3m" and nb_token is not None  and  nb_token != "0" and USER is not None :
                user = await self.client.fetch_user(USER.id)
                with open(f'./db/{type}/tokens.json', 'r') as f:
                            prefixes = json.load(f)
                token_file = {
                    "token" : []
                }
                nb_int = int(nb_token)
                
                boucle_nb =-1
                
                for i in range(0, nb_int):
                        
                        boucle_nb +1
                        
                        try :
                            token_file["token"].append(prefixes["tokens"][boucle_nb])
                        except :
                            await ctx.send("you don't have much token")
                            break 
                        tk_remove = prefixes["tokens"][boucle_nb]
                        
                        with open(f'./db/{type}/tokens.json', 'r') as f:
                        
                            prefixes = json.load(f)
                        
                        prefixes["tokens"].remove(tk_remove)
                        
                        with open(f'./db/{type}/tokens.json', 'w') as f:
                        
                            json.dump(prefixes, f, indent=4)
                
                await user.send(token_file["token"])
                
                await ctx.send(f"Token send with success ! at <@{USER.id}>")
                
                boucle_nb_remove =-1

                token_file["token"] = []
            else :
                await ctx.send("syntax error")
        else : 
            await ctx.send("you haven't authorized to use this command")