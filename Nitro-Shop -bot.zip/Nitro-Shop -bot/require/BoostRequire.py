import colorama, tls_client, json
import discord
import aiohttp
import os
import tasksio
import asyncio
sub_ids = []
colorama.init(convert=True)
async def join_server(token, inv):
  headers = {"Authorization": token, "accept": "*/*", "accept-language": "en-US", "connection": "keep-alive", "cookie": f'__cfduid={os.urandom(43).hex()}; __dcfduid={os.urandom(32).hex()}; locale=en-US', "DNT": "1", "origin": "https://discord.com", "sec-fetch-dest": "empty", "sec-fetch-mode": "cors", "sec-fetch-site": "same-origin", "referer": "https://discord.com/channels/@me", "TE": "Trailers", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9001 Chrome/83.0.4103.122 Electron/9.3.5 Safari/537.36", "X-Super-Properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDAxIiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDIiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6ODMwNDAsImNsaWVudF9ldmVudF9zb3VyY2UiOm51bGx9"}
  async with aiohttp.ClientSession(headers=headers) as serverjoinersession:
    async with serverjoinersession.post(f"https://discord.com/api/v9/invites/{inv}") as response:
        print("join")
async def start_join(inv, tk):
  async with tasksio.TaskPool(10_000) as pool:
      await pool.put(join_server(tk, inv))
def get_type() :
    with open(f'db/type/type.json', 'r') as f:
            typejson =json.load(f)
    type = typejson["type"]
    return type

class Nitro:
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "accept": "*/*",
            "accept-encoding": "gzip, deflate, br",
            "accept-language": "en-US",
            "authorization": token,
            "referer": "https://discord.com/channels/@me",
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9007 Chrome/91.0.4472.164 Electron/13.6.6 Safari/537.36",
            "x-debug-options": "bugReporterEnabled",
            "x-discord-locale": "en-US",
            "x-super-properties": "eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDA3Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDMiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6ImVuLVVTIiwiY2xpZW50X2J1aWxkX251bWJlciI6MTYxODQyLCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ=="
        }
        self.session = tls_client.Session(client_identifier="chrome_107")
        self.sub_ids = []

    def removeTokenFromTxt(self):
        type = get_type()
        with open(f"db/{type}/tokens.txt", "r") as f:
            lines = f.readlines()
        with open(f"db/{type}/tokens.txt", "w") as f:
            for line in lines:
                if line.strip("\n") != self.token:
                    f.write(line)

    def hasNitro(self):
        sex = self.session.get(
            "https://discord.com/api/v9/users/@me/guilds/premium/subscription-slots",
            headers=self.headers,
        )
        if sex.status_code in [403, 401]:
            return self._extracted_from_hasNitro_7('Token is invalid, removing.')
        try:
            for sub in sex.json():
                self.sub_ids.append(sub["id"])
        except Exception as e:
            print(e)
            print(sex.text)
        if len(self.sub_ids) == 0:
            return self._extracted_from_hasNitro_7('Token has no nitro, removing.')
        log(f"{colorama.Fore.GREEN}Token has nitro.")
        return True

    # TODO Rename this here and in `hasNitro`
    def _extracted_from_hasNitro_7(self, arg0):
        log(f"{colorama.Fore.RED}{arg0}")
        self.removeTokenFromTxt()
        return False

    def boostServer(self, guildID, boost_nb):
        for i in range(len(self.sub_ids)):
            self.headers["Content-Type"] = "application/json"
            r = self.session.put(
                url=f"https://discord.com/api/v9/guilds/{guildID}/premium/subscriptions",
                headers=self.headers,
                json={
                    "user_premium_guild_subscription_slot_ids": [f"{self.sub_ids[i]}"]
                },
            )
            
            if r.status_code == 201:
                log(
                    f"{colorama.Fore.GREEN}Boosted {i + 1} of {len(sub_ids)} from {self.token[25:]}"
                )
                self.removeTokenFromTxt()
                boost_nb  = boost_nb +1
            elif r.status_code == 400:
                log(
                    f"{colorama.Fore.YELLOW}Boost already used {i + 1} of {len(sub_ids)} from {self.token[25:]}"
                )
                self.removeTokenFromTxt()
            else:
                log(f"{colorama.Fore.RED}ERROR: {r.status_code}")

        return boost_nb


def log(text):
    print(f"{text}{colorama.Fore.RESET}")

async def main(__guild_id__, type, nb_boost, INV):
    type_remove = type
    boost_nb = 0
    check_nb_boost = 0
    with open(f"db/{type}/tokens.txt", "r") as f:
        tokens = f.read().splitlines()
    for token in tokens:
        nitro = Nitro(token)
        if nitro.hasNitro():
            if  boost_nb == nb_boost:
                return
            else :
                    await start_join(inv = INV, tk  = token)
                    nitro.boostServer(__guild_id__, boost_nb)
                    
                    print(check_nb_boost)

    return boost_nb
