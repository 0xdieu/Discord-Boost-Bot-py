import json
class check :
    def owner(id):
        with open('./db/whitelist/owner.json', 'r') as f:
            prefixes = json.load(f)
        lenowner = len(prefixes['owner'])
        ownerlen = -1
        for i in range(0,lenowner):
            ownerlen + 1
            if prefixes['owner'][ownerlen]  == str(id):
                return True 